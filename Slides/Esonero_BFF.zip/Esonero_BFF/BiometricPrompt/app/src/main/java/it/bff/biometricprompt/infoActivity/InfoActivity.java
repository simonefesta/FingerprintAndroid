package it.bff.biometricprompt.infoActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import it.bff.biometricprompt.R;


public class InfoActivity  extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
    }
}
